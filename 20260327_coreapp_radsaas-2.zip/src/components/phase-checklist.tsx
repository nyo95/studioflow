"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { toggleChecklist } from "@/app/actions";
import { Checkbox } from "@/components/ui/checkbox";
import { cn } from "@/lib/utils";
import { Loader2 } from "lucide-react";

interface ChecklistItem {
  id: string;
  label: string;
  is_checked: boolean;
}

interface PhaseChecklistProps {
  items: ChecklistItem[];
  isLocked: boolean;
  canEdit: boolean;
  phaseStatus: string;
}

export function PhaseChecklist({
  items,
  isLocked,
  canEdit,
  phaseStatus,
}: PhaseChecklistProps) {
  const [loading, setLoading] = useState<string | null>(null);
  const router = useRouter();
  const isDisabled = isLocked || !canEdit || phaseStatus !== "IN_PROGRESS";

  const handleToggle = async (id: string, checked: boolean) => {
    if (isDisabled) return;
    setLoading(id);
    try {
      await toggleChecklist(id, checked);
      router.refresh();
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(null);
    }
  };

  if (items.length === 0) return null;

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-1 gap-3">
        {items.map((item) => (
          <div 
            key={item.id}
            className={cn(
              "flex items-center gap-3 p-3 rounded-lg border transition-all select-none",
              item.is_checked 
                ? "bg-slate-50 border-slate-100 text-slate-400 opacity-60" 
                : "bg-white border-zinc-200 shadow-sm hover:border-zinc-300"
            )}
          >
            <div className="relative h-5 w-5 flex items-center justify-center shrink-0">
              {loading === item.id ? (
                <Loader2 className="h-3 w-3 animate-spin text-slate-400" />
              ) : (
                <Checkbox 
                  id={item.id}
                  checked={item.is_checked}
                  disabled={isDisabled}
                  onCheckedChange={(checked) => handleToggle(item.id, checked === true)}
                  className="data-[state=checked]:bg-slate-900 data-[state=checked]:border-slate-900 rounded-sm"
                />
              )}
            </div>
            <label 
              htmlFor={item.id}
              className={cn(
                "text-xs font-sans font-medium cursor-pointer flex-1 py-0.5 leading-relaxed",
                item.is_checked && "line-through"
              )}
            >
              {item.label}
            </label>
          </div>
        ))}
      </div>
    </div>
  );
}
